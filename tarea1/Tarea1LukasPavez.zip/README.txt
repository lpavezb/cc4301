Debe abrirse tarea1.circ con Logisim (http://www.cburch.com/logisim/)

Para simular se debe seguir la siguiente configuracion: 
En la ventana simulate de Logisim ir a la opcion Tick Frequency y elegir 16 Hz o mayor, 
despues se debe elegir la opcion Ticks Enabled.

Finalmente, con la herremienta para cambiar valores de Logisim (la manito) se debe presionar el boton con el tag reset.

Ahora puede simular utilizando el joystick y el boton button.