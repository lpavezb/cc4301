
int main(){
	char c[] = "hello";
	
	return 1;
}