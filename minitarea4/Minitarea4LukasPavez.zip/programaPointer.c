#include <stdio.h>
int main(){
	int v = 5;
	int *p;
	p = &v;
	
	return *p;
}