
int main(){
	int i=0;
	switch(i){
		case 0:
			i=5;
		case 1:
			i=4;
		case 2:
			i=3;
		case 3:
			i=2;
		case 4:
			i=1;
	}
	return i;
}