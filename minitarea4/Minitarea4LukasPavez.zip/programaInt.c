int main(){
	int i = 5;
	return i+5;
}