int main(){
	char i = 'a';
	return i;
}