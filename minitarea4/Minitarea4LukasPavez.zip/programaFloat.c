int main(){
	float i = 5.0;
	return i;
}