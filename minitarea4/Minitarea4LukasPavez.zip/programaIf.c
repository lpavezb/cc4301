
int main(){
	int v = 5;
	if(v <= 9)
		return v;
	else
		return 2;
}