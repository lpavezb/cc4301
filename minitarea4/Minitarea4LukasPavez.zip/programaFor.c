
int main(){
	int i;
	int j = 0;
	for (i = 0; i < 8; i++){
		j++;
	}
	return j;
}