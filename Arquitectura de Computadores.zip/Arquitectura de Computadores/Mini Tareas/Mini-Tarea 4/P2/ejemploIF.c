#include <stdio.h>


int main() {
  int a = 1;
  if (a== 1)
    printf("hola");
  else
    printf("chao");
}
