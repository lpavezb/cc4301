int main() {
  int a = 1;
  while(a<10)
    a++;
}
