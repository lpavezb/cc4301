#include <stdio.h>

int main () {
  char grade = 'B';
  
  switch(grade) {
    case 'A' :
      printf("hola" );
    default :
      printf("chao");
  }
}
