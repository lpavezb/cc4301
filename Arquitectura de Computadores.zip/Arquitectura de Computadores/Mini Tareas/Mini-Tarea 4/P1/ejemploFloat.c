int main() {
	float a = 1.2;
}
