int main() {
	char a[2];
	a[0] = 'h';
	a[1] = 'o';
}
