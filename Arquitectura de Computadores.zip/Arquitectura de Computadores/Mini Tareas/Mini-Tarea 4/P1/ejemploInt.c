int main() {
	int a = 1;
}
