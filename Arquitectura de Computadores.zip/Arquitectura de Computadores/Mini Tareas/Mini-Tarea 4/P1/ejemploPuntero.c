#include <stdio.h>

int main() {
  int a = 1;
	int* b = &a;
  printf("%i\n", a);
}
