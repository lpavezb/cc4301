int main() {
	char a = '1';
}
